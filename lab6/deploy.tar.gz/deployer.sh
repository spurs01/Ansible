#!/bin/bash

echo "I would be deploying some stuff."

sleep 5

echo "I would be deploying some more stuff."
